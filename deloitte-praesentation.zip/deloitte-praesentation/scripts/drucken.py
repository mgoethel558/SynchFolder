# -*- coding: utf-8 -*-
"""Druckt eine praesentation-HTML als PDF — ohne Node, direkt über Chrome/Edge (CDP).

Ersetzt das Node-Skript pdf_bauen.js des vollen praesentation-Skills: setzt im DOM die
Klassen `deck pdf`, entfernt die Vortrags-Zustände (data-theme, on-brand, Video-Steuerung),
wartet auf die Schriften und druckt dann jede Folie als eigene Seite 1920 × 1080 px
(aus dem @page-Format des Themes).

Aufruf (System-Python; unter Windows meist `python`):
  python drucken.py <deck.html> [ausgabe.pdf] [--vorschau]

- ausgabe.pdf  optional; Default: gleicher Name/Ordner wie die HTML.
- --vorschau    zusätzlich jede Seite als PNG daneben rendern (visuelle Kontrolle ohne Node).

Fehlende Python-Pakete (websocket-client; pypdfium2 nur für --vorschau) zieht das Skript
selbst per `pip --user` nach. Braucht lokal Chrome oder Edge (Chromium).
"""
import argparse, base64, json, shutil, socket, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path


def _ensure(mod, pkg=None):
    try:
        return __import__(mod)
    except ImportError:
        pkg = pkg or mod
        print(f"[i] installiere fehlendes Paket: {pkg}")
        subprocess.run([sys.executable, "-m", "pip", "install", "--user", "--quiet", pkg], check=True)
        return __import__(mod)


# ----------------------------------------------------------- CLI
ap = argparse.ArgumentParser(description="praesentation-HTML -> PDF (Node-frei, über Chrome/Edge)")
ap.add_argument("input", help="Pfad zur Deck-HTML")
ap.add_argument("output", nargs="?", help="Ziel-PDF (Default: gleicher Name/Ordner)")
ap.add_argument("--vorschau", action="store_true", help="jede Seite zusätzlich als PNG rendern")
args = ap.parse_args()

SRC = Path(args.input).resolve()
if not SRC.exists():
    sys.exit(f"[Fehler] Datei nicht gefunden: {SRC}")
OUT = Path(args.output).resolve() if args.output else SRC.with_suffix(".pdf")

websocket = _ensure("websocket", "websocket-client")

# ----------------------------------------------------------- Chromium finden
CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    shutil.which("google-chrome") or "", shutil.which("chromium") or "",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
]
browser = next((c for c in CANDIDATES if c and Path(c).exists()), None)
if not browser:
    sys.exit("[Fehler] Kein Chrome/Edge gefunden (für HTML->PDF erforderlich).")
print(f"[i] Browser: {browser}")


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


PORT = free_port()
profile = tempfile.mkdtemp(prefix="cdp_")
proc = subprocess.Popen([
    browser, "--headless=new", "--disable-gpu", "--no-first-run",
    "--no-default-browser-check", "--disable-extensions", "--remote-allow-origins=*",
    f"--remote-debugging-port={PORT}", f"--user-data-dir={profile}", "about:blank",
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def http_json(path):
    with urllib.request.urlopen(f"http://127.0.0.1:{PORT}{path}", timeout=2) as r:
        return json.loads(r.read().decode())


ws_url = None
for _ in range(80):
    try:
        pages = [t for t in http_json("/json")
                 if t.get("type") == "page" and "webSocketDebuggerUrl" in t]
        if pages:
            ws_url = pages[0]["webSocketDebuggerUrl"]; break
    except Exception:
        pass
    time.sleep(0.25)
if not ws_url:
    proc.terminate(); sys.exit("[Fehler] CDP-Endpoint nicht erreichbar.")

ws = websocket.create_connection(ws_url, max_size=None)
_id = 0


def cmd(method, params=None):
    global _id
    _id += 1; mid = _id
    ws.send(json.dumps({"id": mid, "method": method, "params": params or {}}))
    while True:
        msg = json.loads(ws.recv())
        if msg.get("id") == mid:
            if "error" in msg:
                raise RuntimeError(f"{method}: {msg['error']}")
            return msg.get("result", {})


def wait_event(name, timeout=20):
    end = time.time() + timeout
    while time.time() < end:
        if json.loads(ws.recv()).get("method") == name:
            return


# ----------------------------------------------------------- Rendern (wie pdf_bauen.js)
cmd("Page.enable")
cmd("Runtime.enable")
cmd("Page.navigate", {"url": SRC.as_uri()})
wait_event("Page.loadEventFired")
# PDF-Modus erzwingen, Vortrags-Zustände entfernen — identisch zu pdf_bauen.js
cmd("Runtime.evaluate", {"expression": """
  (function(){
    var r = document.documentElement;
    r.classList.add('deck','pdf');
    r.removeAttribute('data-theme');
    document.body.classList.remove('on-brand','show-notes');
    document.querySelectorAll('video').forEach(function(v){ v.removeAttribute('controls'); });
  })();
"""})
# Auf die Schriften warten, dann drucken
cmd("Runtime.evaluate", {"expression": "document.fonts.ready", "awaitPromise": True})
time.sleep(0.5)

# @page size:1920px 1080px aus dem Theme-CSS: eine Folie pro Seite
data = cmd("Page.printToPDF", {
    "printBackground": True, "preferCSSPageSize": True,
    "marginTop": 0, "marginBottom": 0, "marginLeft": 0, "marginRight": 0,
})["data"]
OUT.write_bytes(base64.b64decode(data))

try:
    ws.close(); proc.terminate()
except Exception:
    pass
shutil.rmtree(profile, ignore_errors=True)

# ----------------------------------------------------------- Seitenzahl + optionale Vorschau
pypdf = _ensure("pypdf")
from pypdf import PdfReader
seiten = len(PdfReader(str(OUT)).pages)
print(f"[OK] {OUT}  ({OUT.stat().st_size // 1024} KB, {seiten} Seiten)")

if args.vorschau:
    pdfium = _ensure("pypdfium2")
    doc = pdfium.PdfDocument(str(OUT))
    for i in range(len(doc)):
        png = OUT.with_name(f"{OUT.stem}-folie-{i + 1:02d}.png")
        doc[i].render(scale=0.75).to_pil().save(str(png))
        print(f"[i] Vorschau: {png.name}")
