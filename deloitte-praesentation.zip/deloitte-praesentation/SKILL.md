---
name: deloitte-praesentation
description: >-
  Erstellt eine HTML-Präsentation im Deloitte-Look als eine einzige, offline lauffähige
  Datei (schwarze Titelfolie mit „Deloitte."-Schriftzug und grünem Punkt, Deloitte-Grün
  als Akzent, Segoe UI) und kann sie als PDF drucken (eine Folie pro Seite, 1920 × 1080).
  Standardmäßig ist das Deloitte-Theme gesetzt — kein --theme nötig. Die HTML läuft im
  Präsentationsmodus (Pfeiltasten, Klick, Wischen, Sprechernotizen mit Taste N, Hell/Dunkel,
  Vollbild) und im Lesemodus fürs Handy. Das Drucken läuft über lokales Chrome/Edge und
  braucht KEIN Node. Diesen Skill nutzen, wenn eine Präsentation, ein Deck, Folien, ein
  Vortrag oder ein Pitch im Deloitte-Design verlangt wird — auch wenn der Nutzer „HTML"
  nicht erwähnt — oder wenn aus so einer Präsentation ein PDF entstehen soll. Nicht nutzen,
  wenn ausdrücklich eine .pptx- oder Google-Slides-Datei verlangt ist, oder wenn aus einer
  Markdown-Datei ein PDF-Dokument (kein Foliensatz) werden soll — dafür ist deloitte-pdf da.
---

# Deloitte-Präsentation erstellen

`<skill>` steht unten für den Ordner dieses Skills (der Basisordner, aus dem diese Datei
geladen wurde, i. d. R. `~/.claude/skills/deloitte-praesentation`). Alle Skripte finden
ihre Vorlagen relativ zu sich selbst.

Dieser Skill ist eine feste, Deloitte-gebrandete und **Node-freie** Fassung der
Präsentations-Engine: anlegen (`neu.py`) und drucken (`drucken.py`) laufen mit System-Python
und lokalem Chrome/Edge. Nur **Python 3.9+** und **Chrome oder Edge** werden gebraucht.

## Was entsteht

| Fassung | Datei | Wofür |
|---|---|---|
| **Vortragsfassung** (Quelle) | `<name>.html` + `media/` daneben | Vortrag am Laptop/Beamer; mit Sprechernotizen (Taste N) |
| **PDF** | `<name>.pdf`, 1920 × 1080 pro Folie | Versand, Handy, Ausdruck |

Die HTML läuft in drei Modi: Präsentation (ab 900 × 560 px mit JS), Lesemodus (darunter
oder ohne JS — Folien untereinander) und PDF (gesetzt von `drucken.py`).

## Ablauf

### 1. Rahmen klären

Vor dem ersten Satz aus dem Gespräch ableiten, nur Fehlendes fragen: **Anlass, Publikum,
Dauer** (Faustregel: eine Folie pro Minute, 8–14 Folien), **Material** (Fotos, Screenshots,
Logos), **Ablage und Versand**, **Sprache** (`de` Standard oder `en`). Das Theme ist fix
Deloitte — nicht erfragen.

### 2. Storyline vor Gestaltung

Eine Folienliste schreiben: je Folie Eyebrow, Überschrift als **Aussage** (ganzer Satz),
Inhalt in Stichworten, Baustein aus `references/bausteine.md`, Inhalt der Sprechernotiz.
Bei mehr als einer Handvoll Folien die Liste dem Nutzer zeigen und das OK abwarten —
umbauen ist in der Liste billig, im HTML teuer.

### 3. Gerüst anlegen

```
python <skill>/scripts/neu.py <ordner>/<name>.html --titel "…" [--sprache en] [--galerie]
```

Das Deloitte-Theme ist Standard — **kein `--theme` und kein `--marke` nötig** (die Wortmarke
„Deloitte." steckt fest im Theme). `--galerie` legt statt der drei Startfolien alle Bausteine
als Vorlage an. Überschreibt nichts ohne `--ueberschreiben`. Die erzeugte Datei ist ab jetzt
die Quelle.

### 4. Folien schreiben

In der erzeugten Datei die Folien zwischen `<main id="deck">` und `</main>` ersetzen.
Bausteine und ihre Regeln: `references/bausteine.md`; lauffähige Beispiele mit `--galerie`.
Eigenes CSS nur in den Block „Folienspezifische Ergänzungen", Farben nur über `var(--d-*)`.
Engine- und Theme-Block nicht anfassen.

Schreibregeln:
- Überschrift = Aussage der Folie, nicht Thema („Der Pilot ist kostenlos — und ehrlich
  begrenzt." statt „Pilot").
- Höchstens vier Punkte, jeder ein ganzer Satz. Was gesagt, aber nicht gelesen werden soll,
  gehört in die Sprechernotiz (`aside.notes`).
- Keine erfundenen Zahlen, Zitate oder Logos. Beispielwerte als Beispiel kennzeichnen.
- Platzhalter für Fehlendes sichtbar lassen (`.placeholder` oder `[eckige Klammern]`) und
  dem Nutzer auflisten.

### 5. Bilder einbauen

Originale nach `media/`, bearbeitete Fassungen als `media/praes-*.jpg|png`, mit echten
`width`/`height` und sprechendem `alt`. Personen, die nicht gezeigt werden sollen, vor dem
Einbau unkenntlich machen.

### 6. Als PDF drucken

```
python <skill>/scripts/drucken.py <name>.html [<name>.pdf] [--vorschau]
```

Setzt im Dokument den PDF-Modus (`deck pdf`), entfernt Sprechernotizen-Panel und
Bedienleiste, druckt über Chrome/Edge jede Folie als Seite 1920 × 1080. `--vorschau`
rendert zusätzlich jede Seite als PNG daneben (`<name>-folie-01.png`, …) — so lässt sich
das Ergebnis **ohne Node** visuell prüfen. Nach dem Druck mindestens die Titelfolie und
eine dichte Folie ansehen; bei Überlauf kürzen statt Schrift verkleinern.

## Aufbau des Skills

```
assets/engine.css, engine.js      markenneutrale Engine (Modi, Navigation, Bausteine)
assets/geruest.html               Seitengerüst mit Platzhaltern
assets/themes/deloitte/           Standard-Theme (theme.css Token, theme.json Lockup)
assets/folien/start.html          drei Startfolien (Titel, Inhalt, Schluss)
assets/folien/galerie.html        jeder Baustein einmal
scripts/neu.py                    legt eine neue Präsentation an (Deloitte als Standard)
scripts/drucken.py                HTML -> PDF über Chrome/Edge (Node-frei)
scripts/kontrast.py               WCAG-Prüfung des Themes
references/bausteine.md           Katalog der Bausteine mit Regeln — vor dem Schreiben lesen
```

## Design (fix, Deloitte-CI)

- Deloitte-Grün `#86BC25` (Flächen, Punkte, Balken), dunkelgrün `#046A38` als Textakzent
  (WCAG-AA-sicher), Text `#121212`, Grau `#75787B`.
- Titel-/Schlussfolie (`slide--brand`): schwarzer Grund, „Deloitte." mit grünem Punkt.
- Farben nur über `var(--d-*)`, damit Hell/Dunkel-Umschaltung und PDF stimmen. Nach jeder
  Theme-Änderung `python <skill>/scripts/kontrast.py <skill>/assets/themes/deloitte` laufen
  lassen (muss ohne `FAIL`/`??` durchlaufen).

## Voraussetzungen / Grenzen

- Braucht **Python 3.9+** (nur Standardbibliothek; `drucken.py` zieht `websocket-client`
  und für `--vorschau` `pypdfium2`/`pypdf` selbst per `pip --user` nach) und lokal
  **Chrome oder Edge**. **Kein Node, kein Pandoc.**
- Systemschriften (Segoe UI / Open Sans) — Aussehen hängt leicht vom Rechner ab, kein
  Netzwerkzugriff.
- **Keine automatische Überlaufprüfung:** Das Node-Werkzeug `pruefen.js` (prüft alle
  Auflösungen auf Überlauf/Lesbarkeit) ist hier bewusst nicht enthalten. Stattdessen mit
  `drucken.py --vorschau` die Seiten sichten. Wer die volle Prüfung braucht, nutzt den
  vollständigen `praesentation`-Skill mit Node/Playwright.
- Für Videos und eine mail-taugliche Einzeldatei (alles eingebettet) ebenfalls den vollen
  `praesentation`-Skill verwenden.
