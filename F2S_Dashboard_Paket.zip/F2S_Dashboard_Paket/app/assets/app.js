/* app.js -- Rendering des F2S Outcome Dashboards aus snapshots.json.
   Grafiken via Chart.js (lokal). DE/EN ueber I18N. PDF via window.print(). */

const COLORS = {
  offen: "#b7791f", "in Arbeit": "#2563eb", erledigt: "#157347",
  "nicht relevant": "#9aa3af", unbekannt: "#d14343",
};
const FIT_COLORS = {
  "Fit": "#157347", "Fit with Configuration": "#2f9e5f",
  "Fit with Process Change": "#7bb661", "Gap / Extension Required": "#e50043",
  "Open / To Be Assessed": "#b7791f", "Out of Scope": "#9aa3af",
};
const LOB_PALETTE = ["#e50043","#2563eb","#157347","#b7791f","#7c3aed","#0891b2","#c2410c","#4b5563"];

const state = {
  store: { snapshots: [] },
  cfg: { status_keys: [], main_types: [], extra_types: [], fit_assessment_values: [] },
  charts: {}, sortKey: "lob", sortDir: 1, expanded: {},
};

// ---------- Hilfsfunktionen ----------
function el(id){ return document.getElementById(id); }
function latest(){ const s = state.store.snapshots; return s.length ? s[s.length-1] : null; }
function pct(done, total){ return total ? Math.round(done/total*100) : 0; }

function applyStaticI18n(){
  document.querySelectorAll("[data-i18n]").forEach(n => {
    const v = I18N.t(n.dataset.i18n);
    if (v) n.textContent = v;
  });
  document.documentElement.lang = I18N.get();
  document.body.className = "lang-" + I18N.get();
}

// ---------- Modus-Erkennung ----------
// Datei-Modus: Dashboard.html wurde per Doppelklick (file://) geoeffnet und
// die Daten liegen in window.F2S_DATA (aus data/snapshots.js).
// Server-Modus: Dashboard laeuft ueber localhost mit Backend-API.
function isFileMode(){ return location.protocol === "file:" || !!window.F2S_DATA; }

// ---------- Datenbeschaffung ----------
async function loadSnapshots(){
  if (isFileMode()){
    state.store = (window.F2S_DATA && window.F2S_DATA.store) || {snapshots:[]};
    return;
  }
  const r = await fetch("/api/snapshots", {cache:"no-store"});
  state.store = await r.json();
}
async function loadConfig(){
  if (isFileMode()){
    if (window.F2S_DATA && window.F2S_DATA.config) state.cfg = window.F2S_DATA.config;
    return;
  }
  try { state.cfg = await (await fetch("/api/config",{cache:"no-store"})).json(); }
  catch(e){ /* Defaults bleiben */ }
}

// ---------- Refresh ----------
async function doRefresh(){
  // Im Datei-Modus kann der Browser den SharePoint-Download nicht ausloesen
  // (kein Python/Dateizugriff). Stattdessen Hinweis auf Aktualisieren.bat.
  if (isFileMode()){
    showToast("err", I18N.t("refresh_file_mode_title"), I18N.t("refresh_file_mode_hint"));
    return;
  }
  const btn = el("btnRefresh");
  btn.disabled = true;
  showToast("spin", I18N.t("refreshing"), "");
  setProgress(15);
  try {
    const r = await fetch("/api/refresh", {method:"POST"});
    setProgress(80);
    const res = await r.json();
    if (res.ok){
      await loadSnapshots();
      render();
      setProgress(100);
      const msg = res.unchanged ? I18N.t("refresh_unchanged")
        : `${I18N.t("refresh_ok")} · ${res.files_processed} ${I18N.t("files_processed")}`;
      showToast("ok", msg, "");
    } else {
      showToast("err", I18N.t("refresh_failed"), res.error || "");
    }
  } catch(e){
    showToast("err", I18N.t("refresh_failed"), String(e));
  } finally {
    btn.disabled = false;
    setTimeout(()=>setProgress(0), 600);
  }
}
function setProgress(p){ el("progress").style.width = p + "%"; }
function showToast(kind, title, detail){
  const t = el("toast");
  t.className = "toast show " + (kind==="ok"?"ok":kind==="err"?"err":"");
  const spin = kind==="spin" ? '<span class="spin"></span>' : "";
  t.innerHTML = `${spin}<b>${title}</b>${detail?`<br><span style="font-size:13px;color:#667085">${detail}</span>`:""}`;
  if (kind!=="spin") setTimeout(()=>t.classList.remove("show"), 6000);
}

// ---------- Render-Hauptfunktion ----------
function render(){
  applyStaticI18n();
  const snap = latest();
  const has = !!snap && Object.keys(snap.lob_aggregates||{}).length>0;

  el("emptyState").classList.toggle("hidden", has);
  ["chartSection","kpiSection","tableSection"].forEach(id=>el(id).classList.toggle("hidden", !has));

  // letzte Aktualisierung
  if (snap){
    const d = new Date(snap.timestamp);
    const txt = d.toLocaleString(I18N.get()==="de"?"de-DE":"en-GB");
    el("lastUpdate").textContent = txt;
    el("printDate").textContent = txt;
  } else {
    el("lastUpdate").textContent = I18N.t("never");
  }
  if (!has){ renderWarnings(snap); return; }

  renderWarnings(snap);
  renderTypeSelectors();
  renderKpis(snap);
  renderTable(snap);
  renderCharts(snap);
}

// ---------- Warnungen ----------
function renderWarnings(snap){
  const box = el("warnBox"), list = el("warnList");
  const w = (snap && snap.warnings) || [];
  if (!w.length){ box.classList.add("hidden"); return; }
  box.classList.remove("hidden");
  const labelMap = {
    unknown_status: "warn_unknown_status",
    unknown_record_type: "warn_unknown_record_type",
    placeholder_workshop: "warn_placeholder_workshop",
  };
  list.innerHTML = w.map(x=>{
    const label = labelMap[x.type] ? I18N.t(labelMap[x.type]) : x.type;
    return `<li>${label}: „${x.value}“ ${x.column?`(${I18N.t("in_column")} ${x.column})`:""} — ${I18N.t("in_file")} ${x.file}</li>`;
  }).join("");
}

// ---------- Typ-Auswahl (Grafik A & B) ----------
function renderTypeSelectors(){
  const burn = el("burnupType"), stat = el("statusType");
  const opts = (withAll) => {
    let s = withAll ? `<option value="__all__">${I18N.t("all_types")}</option>` : "";
    state.cfg.main_types.forEach(t => s += `<option value="${t}">${I18N.typ(t)}</option>`);
    return s;
  };
  const bPrev = burn.value || "__all__";
  const sPrev = stat.value || (state.cfg.main_types[0]||"requirement");
  burn.innerHTML = opts(true); burn.value = bPrev;
  stat.innerHTML = opts(false); stat.value = sPrev;
  burn.onchange = ()=>renderChartA(latest());
  stat.onchange = ()=>renderChartB(latest());
}

// ---------- KPIs ----------
function aggregateTotals(snap){
  const totals = {}; state.cfg.main_types.forEach(t=>totals[t]={});
  let workshops = 0;
  Object.values(snap.lob_aggregates).forEach(lob=>{
    workshops += lob.workshops_conducted||0;
    state.cfg.main_types.forEach(t=>{
      const c = lob.counts[t]||{};
      Object.entries(c).forEach(([s,n])=> totals[t][s]=(totals[t][s]||0)+n);
    });
  });
  return { workshops, totals };
}
function sumType(c){ return Object.values(c).reduce((a,b)=>a+b,0); }
function doneOf(c){ return c["erledigt"]||0; }

function renderKpis(snap){
  const {workshops, totals} = aggregateTotals(snap);
  const cards = [];
  cards.push(kpiCard(I18N.t("kpi_workshops"), workshops, null, I18N.t("kpi_conducted")));
  [["requirement","kpi_requirements"],["issue","kpi_issues"],["task","kpi_tasks"],["decision","kpi_decisions"]]
    .forEach(([typ,key])=>{
      const c = totals[typ]||{}; const tot=sumType(c); const dn=doneOf(c);
      cards.push(kpiCard(I18N.t(key), tot, pct(dn,tot), null));
    });
  el("kpis").innerHTML = cards.join("");
}
function kpiCard(label, big, share, suffix){
  let shareHtml = "";
  if (share!==null && share!==undefined){
    shareHtml = `<div class="share">${share}% ${I18N.t("kpi_done_share")}
      <div class="barmini"><i style="width:${share}%"></i></div></div>`;
  } else if (suffix){
    shareHtml = `<div class="share" style="color:var(--muted)">${suffix}</div>`;
  }
  return `<div class="kpi"><div class="label">${label}</div>
    <div class="big">${big}</div>${shareHtml}</div>`;
}

// ---------- Tabelle ----------
function statusCells(c){
  // kompakte Pills offen / in Arbeit / erledigt (nicht relevant/unbekannt nur falls >0)
  const order = ["offen","in Arbeit","erledigt"];
  const extra = ["nicht relevant","unbekannt"];
  let html = "";
  order.forEach(s=>{
    const n = c[s]||0;
    const cls = s.replace(/\s/g,"").toLowerCase();
    html += `<span class="pill ${n?cls:'zero'}" title="${I18N.status(s)}">${n}</span>`;
  });
  extra.forEach(s=>{
    const n = c[s]||0;
    if (n>0){ const cls=s.replace(/\s/g,"").toLowerCase();
      html += `<span class="pill ${cls}" title="${I18N.status(s)}">${n}</span>`; }
  });
  return `<td class="num celltyp">${html}</td>`;
}
function extraCell(counts){
  const a = sumType(counts.assumption||{}), i = sumType(counts.information||{});
  return `<td class="num">${a} / ${i}</td>`;
}

function renderTableHead(){
  const cols = [
    ["lob","col_lob"],["workshops","col_workshops"],["requirement","col_requirements"],
    ["issue","col_issues"],["task","col_tasks"],["decision","col_decisions"],["extra","col_extra"],
  ];
  el("lobHead").innerHTML = "<tr>" + cols.map(([k,i18n])=>{
    const arrow = state.sortKey===k ? (state.sortDir>0?"▲":"▼") : "";
    const numcls = (k!=="lob")?"num":"";
    return `<th class="${numcls}" data-sort="${k}">${I18N.t(i18n)} <span class="arrow">${arrow}</span></th>`;
  }).join("") + "</tr>";
  el("lobHead").querySelectorAll("th").forEach(th=>{
    th.onclick = ()=>{ const k=th.dataset.sort;
      if(state.sortKey===k) state.sortDir*=-1; else {state.sortKey=k;state.sortDir=1;}
      renderTable(latest()); };
  });
}
function sortValue(name, agg, key){
  if (key==="lob") return name.toLowerCase();
  if (key==="workshops") return agg.workshops_conducted||0;
  if (key==="extra") return sumType(agg.counts.assumption||{})+sumType(agg.counts.information||{});
  return sumType(agg.counts[key]||{});
}
function renderTable(snap){
  renderTableHead();
  const lobs = Object.entries(snap.lob_aggregates);
  lobs.sort((a,b)=>{
    const va=sortValue(a[0],a[1],state.sortKey), vb=sortValue(b[0],b[1],state.sortKey);
    return (va<vb?-1:va>vb?1:0)*state.sortDir;
  });
  const body = el("lobBody"); body.innerHTML = "";
  const totals = {workshops:0, counts:{}};
  state.cfg.main_types.concat(state.cfg.extra_types).forEach(t=>totals.counts[t]={});

  lobs.forEach(([name, agg])=>{
    const open = !!state.expanded[name];
    const row = document.createElement("tr");
    row.className = "lob-row";
    row.innerHTML =
      `<td><span class="toggle">${open?"▾":"▸"}</span> ${name}</td>`+
      `<td class="num">${agg.workshops_conducted||0}</td>`+
      statusCells(agg.counts.requirement||{})+statusCells(agg.counts.issue||{})+
      statusCells(agg.counts.task||{})+statusCells(agg.counts.decision||{})+
      extraCell(agg.counts);
    row.onclick = ()=>{ state.expanded[name]=!state.expanded[name]; renderTable(latest()); };
    body.appendChild(row);

    // Area-Unterzeilen
    if (open && agg.areas){
      Object.entries(agg.areas).forEach(([aname, a])=>{
        const ar = document.createElement("tr");
        ar.className = "area-row";
        ar.innerHTML =
          `<td>${aname}</td><td class="num">${a.workshops_conducted||0}</td>`+
          statusCells(a.counts.requirement||{})+statusCells(a.counts.issue||{})+
          statusCells(a.counts.task||{})+statusCells(a.counts.decision||{})+
          extraCell(a.counts);
        body.appendChild(ar);
      });
    }

    // Summe aufaddieren
    totals.workshops += agg.workshops_conducted||0;
    state.cfg.main_types.concat(state.cfg.extra_types).forEach(t=>{
      const c = agg.counts[t]||{};
      Object.entries(c).forEach(([s,n])=> totals.counts[t][s]=(totals.counts[t][s]||0)+n);
    });
  });

  el("lobFoot").innerHTML =
    `<tr class="total-row"><td>${I18N.t("row_total")}</td>`+
    `<td class="num">${totals.workshops}</td>`+
    statusCells(totals.counts.requirement)+statusCells(totals.counts.issue)+
    statusCells(totals.counts.task)+statusCells(totals.counts.decision)+
    extraCell(totals.counts)+`</tr>`;
}

// ---------- Grafiken ----------
function destroy(id){ if(state.charts[id]){ state.charts[id].destroy(); delete state.charts[id]; } }

function renderCharts(snap){ renderChartA(snap); renderChartB(snap); renderChartC(snap); renderChartD(snap); }

// A: Burn-up aus Snapshot-Historie
function renderChartA(snap){
  destroy("A");
  const typ = el("burnupType").value || "__all__";
  const snaps = state.store.snapshots;
  const labels=[], created=[], closed=[];
  const seen = new Set(), closedSeen = new Set();
  snaps.forEach(s=>{
    (s.entries||[]).forEach(e=>{
      if (typ!=="__all__" && e.typ!==typ) return;
      const key = e.outcome_id+"|"+e.typ;
      seen.add(key);
      if (e.status==="erledigt") closedSeen.add(key);
    });
    labels.push(new Date(s.timestamp).toLocaleDateString(I18N.get()==="de"?"de-DE":"en-GB"));
    created.push(seen.size); closed.push(closedSeen.size);
  });
  state.charts["A"] = new Chart(el("chartA"), {
    type:"line",
    data:{labels, datasets:[
      {label:I18N.t("created"), data:created, borderColor:"#2563eb", backgroundColor:"#2563eb22", tension:.25, fill:true},
      {label:I18N.t("closed"), data:closed, borderColor:"#157347", backgroundColor:"#15734722", tension:.25, fill:true},
    ]},
    options:baseOpts({stacked:false})
  });
}

// B: Status pro LoB (gestapelt) fuer gewaehlten Typ
function renderChartB(snap){
  destroy("B");
  const typ = el("statusType").value || state.cfg.main_types[0];
  const lobs = Object.keys(snap.lob_aggregates);
  const statuses = ["offen","in Arbeit","erledigt","nicht relevant","unbekannt"];
  const datasets = statuses.map(st=>({
    label:I18N.status(st),
    data:lobs.map(l=> (snap.lob_aggregates[l].counts[typ]||{})[st]||0),
    backgroundColor:COLORS[st],
  })).filter(ds=> ds.data.some(v=>v>0) || ["offen","in Arbeit","erledigt"].includes(ds.label));
  state.charts["B"] = new Chart(el("chartB"), {
    type:"bar", data:{labels:lobs, datasets}, options:baseOpts({stacked:true})
  });
}

// C: Workshops pro LoB
function renderChartC(snap){
  destroy("C");
  const lobs = Object.keys(snap.lob_aggregates);
  state.charts["C"] = new Chart(el("chartC"), {
    type:"bar",
    data:{labels:lobs, datasets:[{
      label:I18N.t("kpi_workshops"),
      data:lobs.map(l=>snap.lob_aggregates[l].workshops_conducted||0),
      backgroundColor:lobs.map((_,i)=>LOB_PALETTE[i%LOB_PALETTE.length]),
    }]},
    options:baseOpts({stacked:false, legend:false})
  });
}

// D: Fit-Assessment-Verteilung pro LoB (gestapelt)
function renderChartD(snap){
  destroy("D");
  const lobs = Object.keys(snap.lob_aggregates);
  const fitVals = state.cfg.fit_assessment_values.length ? state.cfg.fit_assessment_values
    : [...new Set(lobs.flatMap(l=>Object.keys(snap.lob_aggregates[l].fit_assessment||{})))];
  const datasets = fitVals.map(fv=>({
    label:fv,
    data:lobs.map(l=> (snap.lob_aggregates[l].fit_assessment||{})[fv]||0),
    backgroundColor:FIT_COLORS[fv]||"#9aa3af",
  })).filter(ds=>ds.data.some(v=>v>0));
  state.charts["D"] = new Chart(el("chartD"), {
    type:"bar", data:{labels:lobs, datasets}, options:baseOpts({stacked:true})
  });
}

function baseOpts({stacked, legend=true}){
  return {
    responsive:true, maintainAspectRatio:false,
    plugins:{ legend:{display:legend, position:"bottom", labels:{boxWidth:12,font:{size:11}}} },
    scales:{
      x:{stacked, ticks:{font:{size:11}}},
      y:{stacked, beginAtZero:true, ticks:{precision:0,font:{size:11}}}
    }
  };
}

// ---------- PDF ----------
function doPdf(){ window.print(); }

// ---------- Sprache ----------
function setLang(l){
  I18N.set(l);
  document.querySelectorAll(".lang").forEach(b=>b.classList.toggle("active", b.dataset.lang===l));
  render();
}

// ---------- Init ----------
async function init(){
  I18N.set(I18N.detect());
  document.querySelectorAll(".lang").forEach(b=> b.onclick=()=>setLang(b.dataset.lang));
  el("btnRefresh").onclick = doRefresh;
  el("btnPdf").onclick = doPdf;
  await loadConfig();
  await loadSnapshots();
  render();
}
init();
