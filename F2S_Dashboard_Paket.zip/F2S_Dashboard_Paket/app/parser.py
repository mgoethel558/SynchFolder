"""
parser.py -- Liest eine F2S-Workshop-Outcome-Excel und liefert normalisierte
Daten (Workshop-Metadaten + Eintragsliste) gemaess mapping.config.json.

Keine Hartkodierung von Spaltennamen/Statuswerten -- alles kommt aus der Config.
Unbekannte Status-/Typwerte werden NICHT verworfen, sondern als 'unbekannt'
normalisiert und als Warnung gemeldet.
"""
from __future__ import annotations

import json
from pathlib import Path
from datetime import datetime, date

import openpyxl


def load_config(config_path: str | Path) -> dict:
    with open(config_path, encoding="utf-8") as f:
        return json.load(f)


def _col_to_idx(letter: str) -> int:
    """Spaltenbuchstabe 'A' -> 1, 'B' -> 2, ... (openpyxl ist 1-basiert)."""
    idx = 0
    for ch in letter.strip().upper():
        idx = idx * 26 + (ord(ch) - ord("A") + 1)
    return idx


def _clean(value, placeholders) -> str:
    """Zelleninhalt zu getrimmtem String; Platzhalter werden zu ''."""
    if value is None:
        return ""
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    s = str(value).strip()
    if s in placeholders:
        return ""
    return s


def _norm_status(raw: str, status_map: dict, unknown: str):
    """Rohen Statuswert auf offen/in Arbeit/erledigt/... abbilden.
    Rueckgabe: (normalisiert, war_unbekannt)."""
    if not raw:
        return unknown, False  # leer ist kein 'unbekannter' Fehler
    if raw in status_map:
        return status_map[raw], False
    return unknown, True  # vorhanden, aber nicht in der Zuordnung -> melden


def parse_workbook(path: str | Path, config: dict) -> dict:
    """Parst eine Datei. Liefert:
    {
      "workshop": {...Metadaten...},
      "entries": [ {outcome_id, typ, lob, area, status, record_type, ...}, ... ],
      "warnings": [ {type, value, column, ...}, ... ]
    }
    """
    path = Path(path)
    placeholders = set(config.get("empty_placeholders", []))
    unknown = config.get("unknown_value", "unbekannt")
    warnings: list[dict] = []

    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)

    # --- Workshop Summary -----------------------------------------------
    sc = config["summary_cells"]
    ws_sum = wb[config["sheets"]["summary"]]

    def cell(addr: str) -> str:
        return _clean(ws_sum[addr].value, placeholders)

    workshop = {
        "workshop_id": cell(sc["workshop_id"]),
        "workshop_title": cell(sc["workshop_title"]),
        "workstream": cell(sc["workstream"]),
        "area": cell(sc["area"]),
        "scope_items": cell(sc["scope_items"]),
        "date": cell(sc["date"]),
        "overall_result": cell(sc["overall_result"]),
        "approval_status": cell(sc["approval_status"]),
        "source_file": path.name,
    }
    # Workshop gilt als durchgefuehrt, wenn Overall Result gefuellt ist.
    workshop["conducted"] = bool(workshop["overall_result"])

    # Platzhalter-Erkennung: unausgefuellte Template-Kopien melden, nicht
    # stillschweigend als echten Workshop zaehlen.
    ph_markers = ("WS-ID", "e.g.", "[Enter", "[Name", "[List", "[Paste")
    def is_placeholder(v: str) -> bool:
        return any(m.lower() in v.lower() for m in ph_markers)

    if is_placeholder(workshop["workshop_id"]):
        warnings.append({"file": path.name, "type": "placeholder_workshop",
                         "value": workshop["workshop_id"], "column": "Workshop ID"})
        workshop["is_placeholder"] = True
        workshop["conducted"] = False  # unausgefuellte Vorlage zaehlt nicht

    lob = workshop["workstream"] or unknown
    area = workshop["area"] or unknown
    wsid = workshop["workshop_id"] or path.stem

    # --- Outcome Log ----------------------------------------------------
    log = wb[config["sheets"]["log"]]
    cols = {k: _col_to_idx(v) for k, v in config["log_columns"].items()}
    first_row = config["log_first_data_row"]

    rt_cfg = config["record_types"]
    rt_lookup = {v.lower(): k for k, v in rt_cfg.items()}  # "requirement"->"requirement"
    smaps = config["status_maps"]
    count_rules = config["count_rules"]

    entries: list[dict] = []

    def getval(row, key):
        c = cols.get(key)
        if not c:
            return ""
        return _clean(row[c - 1].value if c - 1 < len(row) else None, placeholders)

    for row in log.iter_rows(min_row=first_row):
        outcome_id = getval(row, "outcome_id")
        record_type_raw = getval(row, "record_type")
        if not outcome_id and not record_type_raw:
            continue  # Leerzeile

        base = {
            "outcome_id": outcome_id or f"{wsid}-?",
            "lob": lob,
            "area": area,
            "workshop_id": wsid,
            "record_type": record_type_raw or unknown,
            "process_step": getval(row, "process_step"),
            "topic": getval(row, "topic"),
        }

        # --- Record-Type-Objekt (Requirement/Issue/Assumption/Information) ---
        rt_key = rt_lookup.get(record_type_raw.lower()) if record_type_raw else None
        if record_type_raw and rt_key is None:
            warnings.append({"file": wsid, "type": "unknown_record_type",
                             "value": record_type_raw, "column": "Record Type"})
        if rt_key in ("requirement", "issue", "assumption", "information"):
            fit_raw = getval(row, "fit_assessment")
            status, unk = _norm_status(fit_raw, smaps["fit_assessment"], unknown)
            if unk:
                warnings.append({"file": wsid, "type": "unknown_status",
                                 "value": fit_raw, "column": "Fit Assessment"})
            entries.append({**base, "typ": rt_key, "status": status,
                            "fit_assessment": fit_raw or ""})

        # --- Decision-Objekt: nur wenn Textfeld 'Decision' gefuellt ---
        decision_field = getval(row, count_rules["decision_if_field"])
        if decision_field:
            ds_raw = getval(row, "decision_status")
            status, unk = _norm_status(ds_raw, smaps["decision_status"], unknown)
            if unk:
                warnings.append({"file": wsid, "type": "unknown_status",
                                 "value": ds_raw, "column": "Decision Status"})
            entries.append({**base, "typ": "decision", "status": status})

        # --- Task-Objekt: nur wenn Textfeld 'Action' gefuellt ---
        action_field = getval(row, count_rules["task_if_field"])
        if action_field:
            as_raw = getval(row, "action_status")
            status, unk = _norm_status(as_raw, smaps["action_status"], unknown)
            if unk:
                warnings.append({"file": wsid, "type": "unknown_status",
                                 "value": as_raw, "column": "Action Status"})
            entries.append({**base, "typ": "task", "status": status,
                            "due_date": getval(row, "due_date")})

    wb.close()
    return {"workshop": workshop, "entries": entries, "warnings": warnings}


if __name__ == "__main__":
    # Kleiner Selbsttest mit einer Datei als Argument.
    import sys
    cfg = load_config(Path(__file__).parent / "mapping.config.json")
    result = parse_workbook(sys.argv[1], cfg)
    print(json.dumps(result, indent=2, ensure_ascii=False))
