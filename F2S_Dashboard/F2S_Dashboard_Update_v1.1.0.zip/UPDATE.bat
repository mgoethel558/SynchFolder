@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ================================================================
echo  F2S Dashboard  -  Update auf v1.1.0
echo ================================================================
echo.
echo Dieses Update ersetzt nur den Programmcode (app + Dashboard.html).
echo Ihre Daten (data), die portable Python und Ihre SharePoint-
echo Einstellung (config.local.json) bleiben erhalten.
echo.
set /p TARGET="Pfad zum vorhandenen Dashboard-Ordner (Enter = uebergeordneter Ordner): "
if "%TARGET%"=="" set "TARGET=.."
echo.
if not exist "%TARGET%\app\" (
    echo !! Im Zielordner "%TARGET%" wurde kein app-Ordner gefunden.
    echo    Bitte den Pfad zum entpackten Dashboard-Paket angeben.
    pause
    exit /b 1
)
echo Sichere vorhandene config.local.json ...
if exist "%TARGET%\app\config.local.json" copy /Y "%TARGET%\app\config.local.json" "%TEMP%\f2s_cfg_backup.json" >nul
echo Spiele neuen Programmcode ein ...
powershell -NoProfile -Command "Copy-Item -Path 'app\*' -Destination (Join-Path '%TARGET%' 'app') -Recurse -Force"
copy /Y "Dashboard.html" "%TARGET%\Dashboard.html" >nul
echo Stelle config.local.json wieder her ...
if exist "%TEMP%\f2s_cfg_backup.json" copy /Y "%TEMP%\f2s_cfg_backup.json" "%TARGET%\app\config.local.json" >nul
echo.
echo Fertig. Das Dashboard ist jetzt auf Version v1.1.0.
echo Bitte Dashboard.html neu laden (bzw. Aktualisieren.bat ausfuehren).
echo.
pause
endlocal
